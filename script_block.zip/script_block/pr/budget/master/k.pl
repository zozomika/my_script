#!/usr/bin/perl

while (<>){
	chomp;
	@fld = split(/,/,$_);
	$port = $fld[0];
	$dir  = $fld[1];
	$in  = $fld[5];
	$int = $fld[6];
	$out = $fld[7];
	print "$port $dir $in $int $out\n";
}
