#!/usr/local/perl-5.8.8/bin/perl
# #!/usr/bin/perl

#V6
#ThanhLu BE/RVC
#feedback bug: thanh.lu.ym@renesas.com
# Automatic gen table location
# Update area incr O.H

#use lib("/design04/M28PT_D_layout01_vf/u2bfcc/usr/thanhlu/CORE_SCRIPT/perl_lib");
use warnings;
use strict;
use Data::Dumper;
use Excel::Writer::XLSX;
use Excel::Writer::XLSX::Utility;
use POSIX;
use File::Temp qw/ tempfile tempdir /;
use Cwd qw/cwd getcwd abs_path/;
use Scalar::Util qw(reftype);


#- INPUT
my %SPEC;
my $onlyphase = undef;
our %PHASE;
our %FFORMAT;
my %SEARCH;
our @INT_GROUP_NAME;
my $Product  = "";
our %path_group_name;

# v6_1 some variables reserved for matching data-block for charting later
my %hoChartData = ();#hash of charting data, this will map with QOR_TBL only (the main table)
					 #structure should be like this:
					 #	hoChartData => {
					 #		<tgtKeyword> => [sheet-name, row, start-column, stop-column]
   #developer control initialized keywords here
   $hoChartData{Phase} = [()];
   $hoChartData{Area_std} = [()];
   $hoChartData{All_TNS} = [()];
   $hoChartData{Std_Area_increse_ratio} = [()];
   $hoChartData{Internal_TNS} = [()];
   $hoChartData{Leak} = [()];
   $hoChartData{TUL_ratio} = [()];
   $hoChartData{THH_ratio} = [()];
   $hoChartData{TWH_ratio} = [()];
   $hoChartData{TSH_ratio} = [()];
   $hoChartData{Duration} = [()];


#==========================================#

#==========================================#
#-DEBUG 0-disable / 1-enable for developer only
my $DEBUG = 0;

#==========================================#

#==========================================#
#EXCEL configure
#- initial
our $VERSION = "v4.0"; our $VER_DATE = "2020/09/22";
our $AUTHOR  = 'ThanhLu - 1601 - BE/RVC';
our $usr_name   =   `whoami`;
chomp($usr_name);
our ($sec, $min, $hour, $mday, $mon, $year,$wday, $yday, $isdst) = localtime(time);
$year -=100;
$year += 2000;
$mon  +=1;
$sec  = sprintf("%02d",$sec);
$min  = sprintf("%02d",$min);
$hour = sprintf("%02d",$hour);
$mday = sprintf("%02d",$mday);
$mon  = sprintf("%02d",$mon);
$year = sprintf("%04d",$year);
our $exTime           = "${year}${mon}${mday}_${hour}${min}${sec}";
our $excel_file_out   = "qor_sum_${usr_name}_${exTime}.xlsx";

#-Location
our $EXCEL_COL_HEADER         = 0;
our $EXCEL_ROW_HEADER         = 3;

our %EXCEL_SPEC;
our %EXCEL_TBL;

#-Proc make excel file
sub sub_make_excel_qor {
  print "Making excel report... ";
  my (%QOR) = @_;

  ##### Set some format properties
  my %font_main = (
      valign     => 'vcenter',
      border     => 1,
      text_wrap  => 0,
  );
  #    bold       => 1,
  my %font_emphasize = (
      align      => 'center',
      color      => 'white',
  );
  my %font_log = (
      align      => 'left',
      valign     => 'vcenter',
      font       => 'Courier New',
      size       => 11,
  );
  my %font_log_LVL = (
      valign     => 'vcenter',
      align      => 'center',
      border     => 1,
      text_wrap  => 1,
      font       => 'Courier New'
  );

  my $COL_WIDTH_0 = 25;
  my $COL_WIDTH_1 = 15;
  my $ROW_HEIGHT_0 = 50;
  my $ROW_HEIGHT_1 = 20;

  my $workbook =  Excel::Writer::XLSX->new($excel_file_out);
  my $tmp_dir = File::Temp->newdir(CLEANUP => 1, DIR =>'.');
  $workbook->set_tempdir($tmp_dir);
  my $format_outline_blank    = $workbook->add_format(align=>'center',%font_main,bg_color=>'#CDCDCD');
  my $format_outline      = $workbook->add_format(align=>'left',  %font_main);
  my $format_TIT_1        = $workbook->add_format(color=>'navy',bold=>1,size=>20);
  my $format_outline_category      = $workbook->add_format(align=>'left',  %font_main, bg_color=>'#D9FEFF');
  my $format_header       = $workbook->add_format(%font_main,%font_emphasize,bg_color=>'#FEEB9A',color=>'#BF9B05');

  my $format_outline_percent_format1 = $workbook->add_format(align=>'left', num_format => '0.0%' ,%font_main);
  my $format_outline_percent_format2 = $workbook->add_format(align=>'left', num_format => '0.00%', %font_main );
  my $format_outline_percent_format3 = $workbook->add_format(align=>'left', num_format => '0.000%', %font_main );

  my $sheet      = $workbook->add_worksheet("qor");
  my $imgSheet   = $workbook->add_worksheet("visulizationImage");
  $sheet->hide_gridlines(2);

  #- Title of table
  $sheet->write($EXCEL_ROW_HEADER-3,$EXCEL_COL_HEADER,"QoR of Design",$format_TIT_1);
  $sheet->set_row($EXCEL_ROW_HEADER-3,$ROW_HEIGHT_1);
  $sheet->write($EXCEL_ROW_HEADER-1,$EXCEL_COL_HEADER,"Working Directory",$format_outline_category);
  $sheet->write($EXCEL_ROW_HEADER-1,$EXCEL_COL_HEADER+1,$SPEC{DIR}{Working});

  #- Appendix
   $sheet->write($EXCEL_ROW_HEADER-3,$EXCEL_COL_HEADER+2,"Product", $format_outline_category);
   $sheet->write($EXCEL_ROW_HEADER-3,$EXCEL_COL_HEADER+3,$SPEC{Product}, $format_outline);
   $sheet->write($EXCEL_ROW_HEADER-3,$EXCEL_COL_HEADER+4,"Created date", $format_outline_category);
   $sheet->write($EXCEL_ROW_HEADER-2,$EXCEL_COL_HEADER+4,"Created by", $format_outline_category);
   $sheet->write($EXCEL_ROW_HEADER-3,$EXCEL_COL_HEADER+5,"$mday-$mon-$year $hour:$min:$sec", $format_outline);
   $sheet->write($EXCEL_ROW_HEADER-2,$EXCEL_COL_HEADER+5,$usr_name, $format_outline);

  $imgSheet->write($EXCEL_ROW_HEADER-2,$EXCEL_COL_HEADER,"Placement",$format_TIT_1);
	  $imgSheet->insert_image('A4', 'RPT/pod/images/uhi31gtmt080.placement.bmp', 0, 0, 0.4, 0.4); 
  $imgSheet->write(24,$EXCEL_COL_HEADER,"Density",$format_TIT_1);
	  $imgSheet->insert_image('A26', 'RPT/pod/images/uhi31gtmt080.density.bmp', 0, 0, 0.4, 0.4); 
  $imgSheet->write($EXCEL_ROW_HEADER-2,$EXCEL_COL_HEADER+13,"Congestion Map",$format_TIT_1);
	  $imgSheet->insert_image('M4', 'RPT/pod/images/uhi31gtmt080.congestion.bmp', 0, 0, 0.4, 0.4); 
  $imgSheet->write(24,$EXCEL_COL_HEADER+13,"Congested Area w/hotspot",$format_TIT_1);
	  $imgSheet->insert_image('M26', 'RPT/pod/images/uhi31gtmt080.congestedArea.bmp', 0, 0, 0.4, 0.4); 

  my $excel_column = $EXCEL_COL_HEADER; #0
  my $excel_row   = $EXCEL_ROW_HEADER; #4
  my $total_column = $excel_column;
  my $total_row = 0;#$excel_row;
  my $sub_total_row = 0;


  my %EXCEL_SPEC_PHASE = %{$EXCEL_SPEC{0}{PHASE}};
  my $noPhase = scalar(keys %EXCEL_SPEC_PHASE);#number of Phase
  my $rowFinishedQORTBL = 0;#row finishing the QOR_TBL, help to start writing charts right after this
  delete($EXCEL_SPEC{0});
  foreach my $i (sort {$a <=> $b} keys %EXCEL_SPEC) { ;# foreach table
      my @tempkey = (keys %{$EXCEL_SPEC{$i}});
      my $name_of_tbl = $tempkey[0]; if ($DEBUG) { print "### $name_of_tbl excel_row $excel_row excel_column $excel_column total_row $total_row\n";}
      if ($name_of_tbl eq "GROUP_PATH_TBL") {next;}
      my %EXCEL_SPEC_TBL = %{$EXCEL_SPEC{$i}};
      #item menu
      $sheet->set_column(0,$excel_column,$COL_WIDTH_0);
      if ($i == 1) {
		$sheet->write($excel_row,$excel_column,"Phase",$format_outline_category); 
		#->v6_1 register the hoChartData for 'Phase' (as x-axis of some combine charts)
		if(! exists $hoChartData{Phase}) {
			#don't need to do so
		}else{
			$hoChartData{Phase} = [($sheet->get_name, $excel_row, $excel_column, $noPhase)];
		}
		#<-
	  }
      my %excel_spec_tbl = %{$EXCEL_SPEC_TBL{$name_of_tbl}};
      foreach my $index_item (sort {$a<=>$b} keys %excel_spec_tbl) {
		my $tgtLeftHeaderStr = ${excel_spec_tbl}{${index_item}};
		#->v6_1 register some hoChartData for later use
		if(%hoChartData){
			foreach my $tmpk (keys %hoChartData){
				($tmpk eq "Phase") && next;
				if ($tmpk eq $tgtLeftHeaderStr){
					$hoChartData{$tmpk} = [($sheet->get_name, $excel_row+$index_item + 1, $excel_column, $noPhase)];
				}else{}
			}
		}
		#<-
        $sheet->write($excel_row+$index_item + 1,$excel_column,$excel_spec_tbl{$index_item},$format_outline_category);
        if ($name_of_tbl eq "SKEWGROUP_TBL") {
           $sheet->write($excel_row+$index_item + 1,$excel_column +1,"MinID",$format_header);
           $sheet->write($excel_row+$index_item + 1,$excel_column +2,"MaxID",$format_header);
           $sheet->write($excel_row+$index_item + 1,$excel_column +3,"AvgID",$format_header);
           $sheet->write($excel_row+$index_item + 1,$excel_column +4,"TargetSkew",$format_header);
           $sheet->write($excel_row+$index_item + 1,$excel_column +5,"Skew",$format_header);
        }
        if ($i > 1) { $total_row += 1;}
		if($i==1){$rowFinishedQORTBL = scalar(keys %excel_spec_tbl)+$excel_row};
      }
      if ( $i < 2) { $total_column += 1; }

      #value of item
      foreach my $ii (sort {$a <=> $b} keys %EXCEL_SPEC_PHASE) {
        my $phase = $EXCEL_SPEC_PHASE{$ii}; if ($DEBUG) { print "#### PHASE $phase \n";}
        if ($name_of_tbl eq "QOR_TBL" || $name_of_tbl eq "INTERNAL_TNS_TBL") {
                my $tmp_row = $excel_row + $EXCEL_TBL{PHASE}{$phase}[0];
                if ($name_of_tbl eq "INTERNAL_TNS_TBL") {$tmp_row +=1;}
                $sheet->write($tmp_row,$excel_column + $EXCEL_TBL{PHASE}{$phase}[1] ,$phase,$format_header); 
                $sheet->set_column($excel_column + $EXCEL_TBL{PHASE}{$phase}[1],$excel_column + $EXCEL_TBL{PHASE}{$phase}[1],$COL_WIDTH_0);
        }
        if (!exists $QOR{$phase}) {if ( $i < 2) { $total_column += 1; } next;}
        my %VALUE = %{$QOR{$phase}};
        foreach my $index_item (sort {$a<=>$b} keys %excel_spec_tbl) {
          my $item = $excel_spec_tbl{$index_item};
          my $val = "";
          if (!exists $VALUE{$item} ) {
            my $check = 0;
              foreach my $ii_item (sort {$a<=>$b} keys %excel_spec_tbl) {
                if (exists $VALUE{$excel_spec_tbl{$ii_item}}) {$check = 1; last;}
              }
            if (!$check) {  last;}
            $val = "";
              if ($name_of_tbl eq "CLOCK_AREA_TBL") {
                $sheet->write($excel_row + $EXCEL_TBL{$name_of_tbl}{$item}[0] ,$excel_column + 1 + $EXCEL_TBL{$name_of_tbl}{$item}[1],$val,$format_outline_blank);
                $sheet->set_column($excel_column + 1 + $EXCEL_TBL{$name_of_tbl}{$item}[1],$excel_column + 1 + $EXCEL_TBL{$name_of_tbl}{$item}[1],$COL_WIDTH_1);
              } else {
                $sheet->write($excel_row + $EXCEL_TBL{$name_of_tbl}{$item}[0] ,$excel_column + $EXCEL_TBL{PHASE}{$phase}[1] + $EXCEL_TBL{$name_of_tbl}{$item}[1],$val,$format_outline_blank);
                $sheet->set_column($excel_column + $EXCEL_TBL{PHASE}{$phase}[1] + $EXCEL_TBL{$name_of_tbl}{$item}[1],$excel_column + $EXCEL_TBL{PHASE}{$phase}[1] + $EXCEL_TBL{$name_of_tbl}{$item}[1],$COL_WIDTH_0);
              }
          } else {
            my $valtemp = $VALUE{$item};
            my $typeofval = ref($valtemp);
            if ($typeofval eq "ARRAY") {
              if ($item eq "SkewGroup") {
                  my $sub_row = $excel_row;
                  foreach my $line (@{$VALUE{$item}}) {
                     my $sub_col = $excel_column;
                     my @arr = split(/\s+/,$line);
                     my $sg = shift @arr;
                     $sheet->write($sub_row + $EXCEL_TBL{$name_of_tbl}{$item}[0] +1 ,$sub_col + $EXCEL_TBL{$name_of_tbl}{$item}[1] ,$sg,$format_outline); #write value of item
                     $sheet->set_column($sub_col + $EXCEL_TBL{$name_of_tbl}{$item}[1],$sub_col + $EXCEL_TBL{$name_of_tbl}{$item}[1],$COL_WIDTH_0);
                     foreach my $no (@arr) {
                       $sub_col +=1;
                       $sheet->write($sub_row + $EXCEL_TBL{$name_of_tbl}{$item}[0] +1 ,$sub_col + $EXCEL_TBL{$name_of_tbl}{$item}[1] ,$no,$format_outline); #write value of item
                       $sheet->set_column($sub_col + $EXCEL_TBL{$name_of_tbl}{$item}[1],$sub_col + $EXCEL_TBL{$name_of_tbl}{$item}[1],$COL_WIDTH_1);
                     }
                     $sub_row +=1;
                  }
                  $sub_total_row = $sub_row - $excel_row;
              } else {
                $val = join("\n", @$valtemp);
                $sheet->write($excel_row + $EXCEL_TBL{$name_of_tbl}{$item}[0] ,$excel_column + $EXCEL_TBL{PHASE}{$phase}[1] + $EXCEL_TBL{$name_of_tbl}{$item}[1],$val,$format_outline);
                $sheet->set_row($excel_row + $EXCEL_TBL{$name_of_tbl}{$item}[0],$ROW_HEIGHT_0);
              }
            } elsif ($typeofval eq "HASH") {
              $val = $VALUE{$item};
              my $sub_row = $excel_row;
              #$sheet->write($excel_row + $EXCEL_TBL{$name_of_tbl}{$item}[0] + $EXCEL_TBL{PHASE}{$phase}[0],$excel_column + $EXCEL_TBL{PHASE}{$phase}[1] ,$phase,$format_header);
              #$sheet->set_column($excel_column + $EXCEL_TBL{PHASE}{$phase}[1],$excel_column + $EXCEL_TBL{PHASE}{$phase}[1],$COL_WIDTH_1);
              foreach my $key (sort(keys %{$val})) {
                 $sheet->write($sub_row + $EXCEL_TBL{$name_of_tbl}{$item}[0] +1 ,$excel_column ,$key,$format_outline); #write name of item
                 $sheet->set_column($excel_column,$excel_column,$COL_WIDTH_0);
                 $sheet->write($sub_row + $EXCEL_TBL{$name_of_tbl}{$item}[0] +1 ,$excel_column + $EXCEL_TBL{PHASE}{$phase}[1] + $EXCEL_TBL{$name_of_tbl}{$item}[1] ,$val->{$key},$format_outline); #write value of item
                 $sheet->set_column($excel_column + $EXCEL_TBL{PHASE}{$phase}[1] + $EXCEL_TBL{$name_of_tbl}{$item}[1],$excel_column + $EXCEL_TBL{PHASE}{$phase}[1] + $EXCEL_TBL{$name_of_tbl}{$item}[1],$COL_WIDTH_1);
                 $sub_row +=1;
              }
              $sub_total_row = $sub_row - $excel_row;
            } else {
              $val = $valtemp;
              if ($name_of_tbl eq "CLOCK_AREA_TBL") {
                $sheet->write($excel_row + $EXCEL_TBL{$name_of_tbl}{$item}[0] ,$excel_column + 1 + $EXCEL_TBL{$name_of_tbl}{$item}[1],$val,$format_outline);
                $sheet->set_column($excel_column + 1 + $EXCEL_TBL{$name_of_tbl}{$item}[1],$excel_column + 1 + $EXCEL_TBL{$name_of_tbl}{$item}[1],$COL_WIDTH_1);
              } else {
                $val =~ s/,//g;
                if ($item =~ /_ratio/) {
					if(! $val =~ /^[-\d\.]+$/){
						print "WARN:: not a number, cannot divide to 100 item='$item' phase='$phase' val='$val'\n";
					}
					#->try to eliminate the error: Argument "N/A" isn't numeric in division (/) at ...
					if ($val && $val =~ /^[\d\.]+$/){
                  $val /= 100; 
					}
				    #<-
                  $sheet->write($excel_row + $EXCEL_TBL{$name_of_tbl}{$item}[0] ,$excel_column + $EXCEL_TBL{PHASE}{$phase}[1] + $EXCEL_TBL{$name_of_tbl}{$item}[1],$val,$format_outline_percent_format3);
                } else {
					#->v6_1 convert to hours
					if($item eq "Duration"){
						$val = &conv_to_hours($val);
					}
					#<-
                  $sheet->write($excel_row + $EXCEL_TBL{$name_of_tbl}{$item}[0] ,$excel_column + $EXCEL_TBL{PHASE}{$phase}[1] + $EXCEL_TBL{$name_of_tbl}{$item}[1],$val,$format_outline);
                }
              }
            }
          }
        }
        $total_column += 1;
      }
     if ($i < 2) { ;#after finish draw table 1, draw others in next side
       $excel_column += $total_column; $total_column = 0;
       $excel_column += 1;

     }
     if ($i >= 2) { ;#after draw table 2, draw others in below
       $excel_row += $total_row; $total_row = 0;
       $excel_row += $sub_total_row; $sub_total_row = 0;
       $excel_row += 2;
     }
  }

  # gen some charts lately
  &sub_gen_combine_chart($workbook, $sheet, "Area_std","Std_Area_increse_ratio"		, $rowFinishedQORTBL +1 , 0);
  &sub_gen_combine_chart($workbook, $sheet, "Area_std","All_TNS"					, $rowFinishedQORTBL +1 , 2);
  &sub_gen_combine_chart($workbook, $sheet, "All_TNS", "Leak",           			, $rowFinishedQORTBL +1 , 4);

  &sub_gen_stackedArea_chart($workbook, $sheet, ["TUL_ratio", "TSH_ratio", "THH_ratio"],  , $rowFinishedQORTBL +1+16 , 0);
  &sub_gen_stackedBar_chart($workbook, $sheet, "Duration"								  , $rowFinishedQORTBL +1+16 , 3);


  $workbook->close();
  print "Done!\n Please check $excel_file_out\n";

}
#==========================================#

#==========================================#

#- All Proc
#==========================================#
#-Proc make array integer for select/filter
sub sub_make_array_by_filter {
  my $x = shift @_;
  if  (!defined $x) {return undef;}
  my @arr;
  if (isdigit($x)) {return int($x);};
  if ($x =~ /(\d{1,})..(\d{1,})/) {
    foreach my $i (${1} .. ${2}) {push(@arr,$i);}
  } else {
    my @tmp = split(' ',$x);
    @arr = @tmp;
  }
  return @arr;
}

#-Proc make empty array
sub sub_empty_arrary {
  my $arr = shift @_;
  while (shift @$arr) {}
}

sub type_of_data {
  my $data = shift @_;
}

#-Proc read specification
sub sub_read_spec {
  my $file           = shift @_;
  my $SPEC           = shift @_;

  my $name_of_hash_lvl1 =  undef;
  my $name_of_hash_lvl11 = undef;
  my $name_of_hash_lvl12 = undef;
  my $name_of_hash_excel_lvl1 = undef;
  my $name_of_hash_excel_lvl11 = undef;
  my $index_phase = 0;
  my $index = 0;
  my $excel_table_index = 0;

  my @stack = ();

  if ($file =~ /\.gz/) { open(FILE,"zcat $file |"); }
  else {open(FILE,$file);}

  my $line = 0;
  while (<FILE>) {
    chomp;
    if ($_ =~/^\s*$/) {next;}
    if ($_ =~/^###/) {next;}
    if ($_ =~ /^,+$/) {next;}
    my @arr = split(/,/,$_);

    if ($_ =~ /^@@@\s/) {
      if (@stack > 0 && defined $name_of_hash_lvl1 && !defined $name_of_hash_lvl11 && !defined $name_of_hash_lvl12) {
        my @tmp = @stack;
        $SPEC->{$name_of_hash_lvl1} = \@tmp;
        splice(@stack);
      }
      if (defined $name_of_hash_lvl11 && @stack > 0) {
        my @tmp = @stack;
        $SPEC->{$name_of_hash_lvl1}{$name_of_hash_lvl11} = \@tmp;
        splice(@stack);
      }
      $arr[0] =~ /^@@@\s(.*)/;
      $name_of_hash_lvl1 = $1;
      $name_of_hash_lvl11 = undef;
      $name_of_hash_lvl12 = undef;
      $SPEC->{$name_of_hash_lvl1} = undef;
    } elsif (defined $name_of_hash_lvl1 && $_ !~ /^@@\s/) {
      if ($_ =~ /^@\s/) {
        if (defined $name_of_hash_lvl11 && @stack > 0) {
          my @tmp = @stack;
          $SPEC->{$name_of_hash_lvl1}{$name_of_hash_lvl11} = \@tmp;
          splice(@stack);
        }
        $arr[0] =~ /^@\s(.*)/;
        $name_of_hash_lvl11 = $1;
        $name_of_hash_lvl12 = undef;
        $SPEC->{$name_of_hash_lvl1}{$name_of_hash_lvl11} = undef;
        if ($name_of_hash_lvl1 eq "PHASE") {$EXCEL_SPEC{$excel_table_index}{$name_of_hash_lvl1}{$index_phase} = $name_of_hash_lvl11; $index_phase+=1; }
      } elsif ($_ =~ /^%\s/) {
        $arr[0] =~ /^%\s(.*)/;
        $name_of_hash_lvl12 = $1;
        $name_of_hash_lvl11 = undef;
        if (@arr > 2) {
          my @tmp = @arr; shift @tmp;
          $SPEC->{$name_of_hash_lvl1}{$name_of_hash_lvl12} = \@tmp;
        } else {
          $SPEC->{$name_of_hash_lvl1}{$name_of_hash_lvl12} = $arr[1];
        }
        if (defined $name_of_hash_excel_lvl1) {$EXCEL_SPEC{$excel_table_index}{$name_of_hash_excel_lvl1}{$index} = $name_of_hash_lvl12; $index+=1; }
      } else {
          push(@stack,$arr[0]);
      }
    }

    if ($_ =~ /^@@\s/) {
      $arr[0] =~ /^@@\s(.*)/;
      $name_of_hash_excel_lvl1 = $1;
      $excel_table_index += 1;
      $index = 0;
    }

    if (eof(FILE)) {
      if (@stack > 0 && defined $name_of_hash_lvl1 && !defined $name_of_hash_lvl11 && !defined $name_of_hash_lvl12) {
        my @tmp = @stack;
        $SPEC->{$name_of_hash_lvl1} = \@tmp;
        splice(@stack);
      }
      $name_of_hash_lvl1 = undef;
      $name_of_hash_lvl11 = undef;
      $name_of_hash_lvl12 = undef;
    }
    $line++;
  }
  close(FILE);
}

#-Proc convert a line to hash with split patttern, with remove pattern
sub sub_line2hashby {
  my $spliter = shift @_;
  my $line = shift @_;
  $line =~ s/^\s+//;
  my @arr = split(/$spliter/,$line);
  my $i = 0;
  my %tmp;
  foreach my $x (@arr) { $tmp{$i} = $x; $i+=1; }
  return %tmp;
}

#-Proc filter data by array
sub sub_filterhashby {
  my $filter = shift @_;
  my @array = &sub_make_array_by_filter($filter);
  my $INPUT  = shift @_;

  my %OUTPUT;
  foreach my $index (@array){
    if (!exists $INPUT->{$index}) {last;}
    $OUTPUT{$index} = $INPUT->{$index}; 
  }
  return %OUTPUT;
}

#-Proc hash to array
sub sub_hash2array {
  my (%hash) = @_;
  my @array;
  foreach my $key (sort {$a<=>$b} keys %hash ){ 
    push(@array,$hash{$key});
  }
  return @array;
}

#-Proc make grouppath timing
sub sub_parse_2_groupath_tim {
  my $GROUPPATH = shift @_;
  my $WNS      = shift @_;
  my $TNS      = shift @_;
  my $NVE      = shift @_;
  my %GP_TNS_WNS_NVE;

  if (!defined $GROUPPATH) {return;}

  foreach my $i (sort {$a<=>$b} keys %$GROUPPATH ) {
    my $gp = $GROUPPATH->{$i};
    $GP_TNS_WNS_NVE{$gp} = {
                             'WNS' => $WNS->{$i},
                             'TNS' => $TNS->{$i},
                             'NVE' => $NVE->{$i},
                           };
  }
  return %GP_TNS_WNS_NVE;
}

#-Proc make InternalGroupTNS
sub sub_makeInternalGroupTNS {
  my $ALL_GR = shift @_;
  my $SPEC = shift @_;
  my %INT_GR_TNS;
  #if (!defined $ALL_GR) {return;}
  foreach my $key (@{$SPEC->{INT_GROUP_NAME}}) {
    if (exists $ALL_GR->{$key}) {
      $INT_GR_TNS{$key} = $ALL_GR->{$key}{TNS};
    }
  }
  return %INT_GR_TNS;
}

#-Proc find/cal wns & tns of internal group only
sub sub_find_wns_tns_int {
  my $ALL_GR = shift @_;
  my $SPEC = shift @_;
  my $wns = 0;
  my $tns = 0;
  if (!defined $ALL_GR) {return;}
  foreach my $g (@{$SPEC->{INT_GROUP_NAME}}) {
    if (!exists $ALL_GR->{$g} || !defined $ALL_GR->{$g}) {next;}
    my $curr_wns = $ALL_GR->{$g}{WNS};
    if ($curr_wns eq 'N/A') {next;}
    $tns = ($ALL_GR->{$g}{TNS}<0)? $tns + $ALL_GR->{$g}{TNS} : $tns;
    if ($curr_wns < $wns) { $wns = $curr_wns; }
  }
  return ($wns, $tns);
}

#-Proc importdata when match
sub sub_linetodata {

  my $line = shift @_;
  $line =~ s/^\s+//;
  my $ignore = shift @_;
  my $spliter = shift @_;
  my $byrow = shift @_;
  my $select = shift @_;
  my $filter = shift @_;
  my $key   = shift @_;
  my $RETURN  = shift @_;

  $line =~ s/$ignore/ /g if defined $ignore;
  my %tmp = &sub_line2hashby($spliter,$line);
  my %filtered = &sub_filterhashby($filter,\%tmp);
  my %selected = &sub_filterhashby($select,\%tmp);
  if (defined $byrow && $byrow>0) {
    my $count = 0;
    if (!exists $RETURN->{$key}{active} || !defined $RETURN->{$key}{active}) {$count = 0;}
    else {$count = (keys %{$RETURN->{$key}{active}});}
    my @tmpS = &sub_hash2array(%selected);
    my @tmpF = &sub_hash2array(%filtered);
    $RETURN->{$key}{active}{$count} = \@tmpS;
    $RETURN->{$key}{stored}{$count} = \@tmpF;
  } else {
    $RETURN->{$key}{active} =\%selected;
    $RETURN->{$key}{stored} =\%filtered;
  }
 
}
#-Proc simply input file
sub sub_simply_file { ;#TODO: not suitable yet
  my $file = shift @_;
  my $SPEC = shift @_;
  my %SEARCH = %{$SPEC->{SEARCH}};
  my %FFORMAT = %{$SPEC->{FFORMAT}};
  my @pattern; 
  my @BUFFER;
  
  my @arr = split('/',$file);
  my $file_name = $arr[-1];
  foreach my $i (keys %SEARCH) {
    if (!defined $SEARCH{$i} || !defined $SEARCH{$i}[0]) {next;}
    my @mysearch = @{$SEARCH{$i}};
    if ($file !~ /$FFORMAT{$mysearch[0]}/) {next;}
    my $tmppat = $mysearch[-1];
    $tmppat =~ s/#@@@#/|/g;
    push(@pattern,$tmppat);
  }

  my $singlepattern = join('|',@pattern);
  if ($DEBUG) {
    print "$singlepattern\n";
    if ($file =~ /\.gz/) {
      $file_name =~ s/\.gz$//;
      system("zgrep -P '$singlepattern' $file > DEBUG_QOR_simply_${file_name}");
      system("gzip -f DEBUG_QOR_simply_${file_name}");
    } else {
      system("grep -P '$singlepattern' $file > DEBUG_QOR_simply_${file_name}");
    }
  }
  if ($file =~ /\.gz/) {
    @BUFFER = `zgrep -P '$singlepattern' $file`;
  } else {
    @BUFFER = `grep -P '$singlepattern' $file`;
  }
  return @BUFFER;
}

#Proc estimate run time
sub sub_job_start {
   my ($s, $m, $h, $dd, $mm, $yy,$wd, $yd, $isd) = localtime(time);
   print "Job start: $s - $m - $h\n";
   return ($s,$m,$h); 
}
sub sub_job_end {
   my ($s, $m, $h, $dd, $mm, $yy,$wd, $yd, $isd) = localtime(time);
   print "Job end: $s - $m - $h\n";
   return ($s,$m,$h); 
}
sub sub_runtime {
  my ($s1,$m1,$h1,$s2,$m2,$h2) = @_;
  my $begin = $s1 + $m1*60 + $h1*60*60;
  my $end = $s2 + $m2*60 + $h2*60*60;
  my $runtime = $end - $begin;
  print "Runtime: $runtime\n";
}

#- Proc read report_tim/log file-#
sub sub_read_file {

  my $file = shift @_;
  my $SPEC = shift @_;
  my $select_phase = shift @_;
  my $RETURN = shift @_;
  my %SEARCH = %{$SPEC->{SEARCH}};
  my %FFORMAT = %{$SPEC->{FFORMAT}};

  my @startime;
  my @endtime;
  my $flag_path_group_name = 0;
  my @BUFFER;

  print "\tReading... $file \n";
  my $sizeoffile = -s $file;
  $sizeoffile = ($sizeoffile / 1024) / 1014;
  if ($sizeoffile > 2) {
    @BUFFER = &sub_simply_file($file,$SPEC); #reduce big file
  } else {
    if ($file =~ /\.gz/) { open(FILE,"zcat $file |"); }
    else {open(FILE,$file);}
    @BUFFER = <FILE>;
    close(FILE);
  }
  
  my @CONTENT = @BUFFER;

  my $lineIndex = 0;

  if ($DEBUG) {
    @startime = &sub_job_start();
  }
  foreach (@CONTENT) {
    chomp;
    if ($_ =~ /Path Group Name/ && ($file =~ /$FFORMAT{TIM_HOLD}/ || $file =~ /$FFORMAT{TIM_SETUP}/)) {
      $flag_path_group_name = 1;
      next;
    }
    if ($flag_path_group_name && $_ =~ /^\s*$/) { $flag_path_group_name = 0;}
    if ($flag_path_group_name) {
      if (/\d{1,}\s*\|\w+/) {
         my $li = $_;
         $li =~ s/[+|]/ /g;
         $li =~ s/^\s+//g;
         my @arrtmp  = split(/\s+/,$li); 
        $path_group_name{$arrtmp[0]} = $arrtmp[1];
      }
    }
    foreach my $i (keys %SEARCH) {
      if (!defined $SEARCH{$i}) {next;}
      my @mySEARCH = @{$SEARCH{$i}};
      if (!defined $mySEARCH[0] || $file !~ /$FFORMAT{$mySEARCH[0]}/) {next;}
      my $fformat = shift @mySEARCH; $fformat = $FFORMAT{$fformat};
      my $ignore  = shift @mySEARCH; if ($ignore eq '') {$ignore = undef;}
      my $spliter = shift @mySEARCH;
      my $select  = shift @mySEARCH;
      my $filter  = shift @mySEARCH;
      my $byrow   = shift @mySEARCH; $byrow = int($byrow);
      my $pattern = shift @mySEARCH;
      if ($file =~ /$FFORMAT{TIM_SETUP}/ && $file =~ /$fformat/ && $file =~ /$FFORMAT{TIM_HOLD}/ && $i =~ /^All_WNS|^All_TNS|^NVE/ ) {next;}
      if ($_ =~ /($pattern)/) { ;#single pattern
        &sub_linetodata($_,$ignore,$spliter,$byrow,$select,$filter,$i,$RETURN);
      } elsif ($pattern =~ /#@@@#/) { ;#continus pattern
          my @patterns = split('#@@@#',$pattern);
          my $firstpattern = shift @patterns;
          my $found = 0;
          if ($_ =~ /$firstpattern/){
            $found = 1;
            my $selectedLine = $BUFFER[$lineIndex];
            my $saveIndex = $lineIndex+1;
            my $pat;
            while( $#patterns>=0 && $found == 1) {
              my $pat = shift(@patterns);
              $found = 0;
              my $endIndex = $saveIndex+999;
              foreach my $nextIndex ($saveIndex .. $endIndex) { ;#find in 100 next lines
                my $nextline = $BUFFER[$nextIndex];
                if ($nextline =~ /$pat/) { $found = 1; $selectedLine= $nextline; $saveIndex = $nextIndex+1; last;}
              }
              if ($found == 0) {print "\t***Error: Pattern '$pat' is not found!\n"; last;}
            }
            if ($found == 1) {
              &sub_linetodata($selectedLine,$ignore,$spliter,$byrow,$select,$filter,$i,$RETURN);
            }
          }
        }
    }
    $lineIndex ++;
  }
  print "\tDone Processing\n";
  if ($DEBUG) {
    @endtime = &sub_job_end();
    &sub_runtime(@startime,@endtime);
  }
 
}

#-Proc hashofarray to array
sub sub_hashofarray2array {
  my (%hash) = @_;
  my @arr;
  foreach my $key (sort {$a<=>$b} keys %hash) {
    my $val = $hash{$key};
    push(@arr,join(' ',@$val));
  }
  return @arr;
}

#-Proc hash to line
sub sub_hash2line {
  my (%hash) = @_;
  my @arr;
  foreach my $key (sort {$a<=>$b} keys %hash) {
    my $val = $hash{$key};
    push(@arr,$val);
  }
  return join(' ',@arr);
}

#-Proc check value inside key of hash
sub sub_ref_a_vaule_of_hash{
  my (%hash) = @_;
  foreach my $val (values %hash) {
    my $ref = ref($val);
   
    return $ref;
  }
}

#-proc rename group path
sub sub_rename_grouppath {
  my $out = shift @_;
  my $path_group_add = shift @_;

  foreach my $key (keys %{$out->{GroupPath}{stored}}) {
    my $val = $out->{GroupPath}{stored}{$key};
    if ($val =~ /(\d{1,}):/) {
      my $id = $1;
      my $newgroup = $path_group_add->{$id};
      $out->{GroupPath}{stored}{$key} = $newgroup;
    }
  }
  foreach my $key (keys %{$out->{GroupPath}{active}}) {
    my $val = $out->{GroupPath}{active}{$key};
    if ($val =~ /(\d{1,}):/) {
      my $id = $1;
      my $newgroup = $path_group_add->{$id};
      $out->{GroupPath}{active}{$key} = $newgroup;
    }
  }
}
#-Proc read by phase
sub sub_phase_reading {
  my $SPEC = shift @_;
  my $select_phase = shift @_;
  my %PHASE = %{$SPEC->{PHASE}};
  my @files = @{$PHASE{$select_phase}};

  #- use for timing summary report -#
  my %OUT; 
  my %GP_TIM;
  my %GP_INT_TIM;

  #- import data 
  print "$select_phase processing...\n";
  while (my $file = shift @files) {

    if (! -e $file ) {
      print "*** ERROR: $file is not existing!\n";
      next;
    }

   &sub_read_file($file, $SPEC, $select_phase, \%OUT);

  }

  if(exists $OUT{GroupPath} && exists $OUT{All_WNS} && exists $OUT{All_TNS} && exists $OUT{NVE}) {
    &sub_rename_grouppath(\%OUT,\%path_group_name);
    %GP_TIM = &sub_parse_2_groupath_tim($OUT{GroupPath}{stored},$OUT{All_WNS}{stored},$OUT{All_TNS}{stored},$OUT{NVE}{stored});
    %GP_INT_TIM = &sub_makeInternalGroupTNS(\%GP_TIM,$SPEC);
    $OUT{InternalGroupTNS}{active}{0} = \%GP_INT_TIM;
    $OUT{InternalGroupTNS}{stored}{0} = \%GP_TIM;
    my ($wns_i,$tns_i) = &sub_find_wns_tns_int(\%GP_TIM,$SPEC);
    $OUT{Internal_WNS}{active}{0} = $wns_i;
    $OUT{Internal_WNS}{stored}{0} = $wns_i;
    $OUT{Internal_TNS}{active}{0} = $tns_i;
    $OUT{Internal_TNS}{stored}{0} = $tns_i;
    my $view = join("\n",&sub_hashofarray2array(%{$OUT{analysisView}{active}}));
  }

  if ($DEBUG) {
     print Dumper(\%OUT);
  }
  return %OUT;
}

#-Proc simplify ouput
sub sub_simplify_output {
  my (%DATA) = @_;
  my %OUT;
  foreach my $key (keys %DATA) {
    my %hash = %{$DATA{$key}{active}};
    my $returnval = "";
    foreach my $i (sort {$a<=>$b} keys %hash) {
      my $val = $hash{$i};
      my $typeofval = ref($val);
      if ($typeofval eq "HASH") {
        #$OUT{$key}{$i} = $val;
        $OUT{$key} = $val;
      } elsif ($typeofval eq "ARRAY" ) {
        my $array2line = join(' ',@$val);
        my @arr = ();
        if (!exists $OUT{$key}) { push(@arr,$array2line); $OUT{$key} = \@arr; } 
        else {push(@{$OUT{$key}},$array2line);} 
      } else {
        if (!exists $OUT{$key}) { $OUT{$key} = $val;}
        else { $OUT{$key}  = $OUT{$key} . " " . $val;}
      }
    }

  }
  return \%OUT;
}

#- find and remove a item from array by pattern
sub sub_array_delete {
  my $pat = shift @_;
  my $arr = shift @_;
  my @tmp = @$arr;

  my $index;
  foreach my $i (0 .. $#tmp) {
    if ($tmp[$i] =~ /$pat/) {
       $index = $i;
       last;
    }
  }
  splice(@$arr, $index, 1);
}
#- find and replace a item from array by pattern
sub sub_array_replace {
  my $pat = shift @_;
  my $arr = shift @_;
  my $replace = shift @_;
  my @tmp = @$arr;

  my $index;
  foreach my $i (0 .. $#tmp) {
    if ($tmp[$i] =~ /$pat/) {
       $index = $i;
       last;
    }
  }
  splice(@$arr, $index, 1, $replace);
}

#-Proc auto get lastest log file run
sub sub_update_latest_log_file {
  my $SPEC = shift @_;
  my $LOG_PREFIX = shift @_;
  my $PHASE = $SPEC->{PHASE};
  my $LOG = $SPEC->{DIR}{LOG};
  
  foreach my $phase (keys %$PHASE) {
    my @files = @{$PHASE->{$phase}};
    foreach my $i (0 .. $#files) {
      my $file = $files[$i];
      if ($file =~ /\/\w*\*\./) {
        $file = `ls -rt $file | tail -n1`;
        chomp $file;
        $PHASE->{$phase}[$i] = $file;
      }
    }
  }
}

sub sub_update_direct_link {
  my $SPEC = shift @_;
  my $PHASE = $SPEC->{PHASE};
  my $Working = $SPEC->{DIR}{Working};
  $SPEC->{DIR}{Working} = &abs_path($Working);
  $Working = $SPEC->{DIR}{Working};
  my @tmppro = split(/\//,$Working); 
  $SPEC->{Product} = $tmppro[-1]; 
  $excel_file_out   = "qor_sum_$SPEC->{Product}_${usr_name}_${exTime}.xlsx";
  
  my $RPT = $SPEC->{DIR}{RPT};
  my $LOG = $SPEC->{DIR}{LOG};

  foreach my $key (keys %{$PHASE}) {
    my @files = @{$PHASE->{$key}};
    foreach my $i (0 .. $#files) {
      my $file = $files[$i];
      if ($file =~ /\.log/) {
        $file = "$Working/$LOG/$file";
      } else {
        $file = "$Working/$RPT/$file";
      }
      $PHASE->{$key}[$i] = $file;
    }
  }
}

sub sub_update_excel_table {
  my $row = shift @_;
  my $col = shift @_;
  foreach my $i (keys %EXCEL_SPEC) {
    foreach my $tbl (keys %{$EXCEL_SPEC{$i}}) {
      my %hashval = %{$EXCEL_SPEC{$i}{$tbl}};
      foreach my $i (sort {$a<=>$b} keys %hashval) {
        my $val = $hashval{$i};
        if ($tbl eq "PHASE" ) {
          #$EXCEL_TBL{$tbl}{$val} = [$row,$col + $i + 1]; 
          $EXCEL_TBL{$tbl}{$val} = [0,$i + 1]; 
        } else {
          #$EXCEL_TBL{$tbl}{$val} = [$row+$i,$col]; 
          $EXCEL_TBL{$tbl}{$val} = [$i+1,0]; 
        }
      }
    }
  }

}

sub sub_update_std_oh_ratio {
  my $QOR =  shift @_;
  if (!exists $QOR->{INIT} || !defined $QOR->{INIT}) {
    return;
  } 

  my $std_init = $QOR->{INIT}{Area_std};
  foreach my $phase (keys %{$QOR}) {
    if (!exists $QOR->{$phase}{Area_std} || !defined $QOR->{$phase}{Area_std}) {next;}
    my $curr_std = $QOR->{$phase}{Area_std};
    #$QOR->{$phase}{Std_Area_increse_ratio} = (($curr_std / $std_init) - 1) * 100;
    $QOR->{$phase}{Std_Area_increse_ratio} = "N/A" 
  }

}
#-Proc check syntax of user
sub sub_check_syntax {
  my $option = shift @_;
  my @OPTIONS = qw/-spec -workdir -rptdir -logdir -loginit -logpod -logcod -logroute -logprod -only/;
  my $correct = 0;
  foreach my $val (@OPTIONS) {
    if ($option eq $val) {$correct = 1;}
  }
  if ($correct == 0) {
    print "!!! ERROR: Syntax error with '$option'\n";
    &sub_print_usage();
    exit;
  }

}

sub sub_print_usage {
  print "*** USAGE: \n${0} -spec <qor_spec_file> \
                           \n\t\t[-workdir <working_directory> \
                           \n\t\t-rptdir <Report directory> \
                           \n\t\t-logdir <Log directory> \
                           \n\t\t-only <INIT|POD|COD|ROUT|PROD> ]\n";
}

#===========     v6.1 sub here ============#
sub sub_gen_combine_chart () {
	### to generate a combine chart (column+line)
	#	the sub will use global var: hoChartData
	#	to be simplified, charts will be generated in same sheet with data
	$DEBUG && print "dbg:: sub_gen_combine_chart @_\n";

	my $workbook	= shift; #workbook 
	my $sheet		= shift; #data sheet as well as the sheet holding charts
	my $keyw4column = shift; #keyword denoting the column-chart serie
	my $keyw4line   = shift; #keyword denoting the line-chart serie
	my $oR  = 0; (@_) && ($oR = shift); # output row for the chart, default is 0
	my $oC  = 0; (@_) && ($oC = shift); # output col for the chart, default is 0 (A1)


	(! defined $workbook) && return 1;
	(! defined $sheet) && return 1;
	foreach my $tmpv ($keyw4column, $keyw4line, "Phase") {
		if(! exists $hoChartData{$tmpv}){
			print "ERROR:: Fatal: developer needs to initialize keyw='$tmpv' in hoChartData.\n";
			return 1;
		}
	}

	# Create a column chart - primary chart
	# Note: alternative use of ranges: [ $sheetname, $row_start, $row_end, $col_start, $col_end ]
	my $cC = $workbook->add_chart(type => 'column', embedded => 1);
	$cC->add_series(
		name => $keyw4column,
		categories => [$hoChartData{Phase}->[0], $hoChartData{Phase}->[1], $hoChartData{Phase}->[1], $hoChartData{Phase}->[2]+1,$hoChartData{Phase}->[3]],
		values => [$hoChartData{$keyw4column}->[0], $hoChartData{$keyw4column}->[1], $hoChartData{$keyw4column}->[1], $hoChartData{$keyw4column}->[2]+1,$hoChartData{$keyw4column}->[3]],
	);

	# Create a line chart, with secondary y2_axis
	my $lC = $workbook->add_chart(type => 'line', embedded => 1);
	$lC->add_series(
		name => $keyw4line,
		categories => [$hoChartData{Phase}->[0], $hoChartData{Phase}->[1], $hoChartData{Phase}->[1], $hoChartData{Phase}->[2]+1,$hoChartData{Phase}->[3]],
		values => [$hoChartData{$keyw4line}->[0], $hoChartData{$keyw4line}->[1], $hoChartData{$keyw4line}->[1], $hoChartData{$keyw4line}->[2]+1,$hoChartData{$keyw4line}->[3]],
		y2_axis => 1,
	);

	# Combine the charts
	$cC->combine($lC);

	# Add chart title, some axis labels (done via primary chart)
	$cC->set_title(name => "$keyw4column vs. $keyw4line");
	$cC->set_x_axis( name => "Phase");
#	$cC->set_y_axis( name_font => { rotation => 90 });
	$cC->set_y_axis( name_font => {rotation=>89}, name => $keyw4column);
	$cC->set_y2_axis( name => $keyw4line);
	$cC->set_legend( position => 'bottom');

	# Insert chart, finishing the work
	$sheet->insert_chart(xl_rowcol_to_cell($oR,$oC, 0, 0),$cC);

	#print "\nDumper hoChartData :\n"; print Dumper(\%hoChartData); print "---------------\n\n";
	
	return 0;
}

sub sub_gen_stackedArea_chart () {
	### to generate a percent-stackedArea of a combination of values (in columns)
	#	the sub will use global var: hoChartData
	#	to be simplified, charts will be generated in same sheet with data
	$DEBUG && print "dbg:: sub_gen_stackedArea_chart @_\n";

	my $workbook	= shift; #workbook 
	my $sheet		= shift; #data sheet as well as the sheet holding charts
	my $raoKeyw     = shift; #reference to array of keywords denoting the data series
	my $oR  = 0; (@_) && ($oR = shift); # output row for the chart, default is 0
	my $oC  = 0; (@_) && ($oC = shift); # output col for the chart, default is 0 (A1)
	my $cT  = "";(@_) && ($cT = shift); # chart Title


	(! defined $workbook) && return 1;
	(! defined $sheet) && return 1;
	foreach my $tmpv (@{$raoKeyw}, "Phase"){
		if(! exists $hoChartData{$tmpv}){
			print "ERROR:: Fatal: developer needs to initialize keyw='$tmpv' in hoChartData.\n";
			return 1;
		}
	}

	# Create a new chart object - primary chart
	# Note: alternative use of ranges: [ $sheetname, $row_start, $row_end, $col_start, $col_end ]
	my $psaC = $workbook->add_chart(type => 'area', subtype => 'percent_stacked', embedded => 1);
	# -> configure the series
	foreach my $keyw (@{$raoKeyw}){
		$psaC->add_series(
			name => $keyw,
			categories => [$hoChartData{Phase}->[0], $hoChartData{Phase}->[1], $hoChartData{Phase}->[1], $hoChartData{Phase}->[2]+1,$hoChartData{Phase}->[3]],
			values => [$hoChartData{$keyw}->[0], $hoChartData{$keyw}->[1], $hoChartData{$keyw}->[1], $hoChartData{$keyw}->[2]+1,$hoChartData{$keyw}->[3]],
		);
	}

	# Add chart title, some axis labels (done via primary chart)
	if($cT eq ""){
		foreach my $tmpv (@{$raoKeyw}){
			$cT .= "$tmpv/";
		}
		$cT =~ s/\/$//;
	}
	$psaC->set_title(name => $cT);
	$psaC->set_x_axis( name => "Phase");
	#$psaC->set_y_axis( name => "XXX");
	$psaC->set_legend( position => 'bottom');

	# Insert chart, finishing the work
	$sheet->insert_chart(xl_rowcol_to_cell($oR,$oC, 0, 0),$psaC);

	return 0;
}

sub sub_gen_stackedBar_chart () {
	### to generate a stackedBar of a combination of values - here is specially for Duration (or TAT of executions of phases)
	#	the sub will use global var: hoChartData
	#	to be simplified, charts will be generated in same sheet with data
	$DEBUG && print "dbg:: sub_gen_stackedBar_chart @_\n";

	my $workbook	= shift; #workbook 
	my $sheet		= shift; #data sheet as well as the sheet holding charts
	my $keyw        = shift; #keyword denoting the data serie
	my $oR  = 0; (@_) && ($oR = shift); # output row for the chart, default is 0
	my $oC  = 0; (@_) && ($oC = shift); # output col for the chart, default is 0 (A1)
	my $cT  = "";(@_) && ($cT = shift); # chart Title


	(! defined $workbook) && return 1;
	(! defined $sheet) && return 1;
	foreach my $tmpv ($keyw, "Phase"){
		if(! exists $hoChartData{$tmpv}){
			print "ERROR:: Fatal: developer needs to initialize keyw='$tmpv' in hoChartData.\n";
			return 1;
		}
	}

	# Create a new chart object - primary chart
	# Note: alternative use of ranges: [ $sheetname, $row_start, $row_end, $col_start, $col_end ]
	my $spC = $workbook->add_chart(type => 'bar', subtype => 'stacked', embedded => 1);
	# -> configure the series
	for(my $i=$hoChartData{$keyw}->[2]+1;$i<=$hoChartData{$keyw}->[3];$i++){
		my $name = "=$hoChartData{Phase}->[0]!" . xl_rowcol_to_cell($hoChartData{Phase}->[1], $i, 1, 1);
		$spC->add_series(
			name => "$name",
			values => [$hoChartData{$keyw}->[0], $hoChartData{$keyw}->[1], $hoChartData{$keyw}->[1], $i, $i],
		);
	}
	#$spC->add_series(
	#	name => $keyw,
	#	categories => [$hoChartData{Phase}->[0], $hoChartData{Phase}->[1], $hoChartData{Phase}->[1], $hoChartData{Phase}->[2]+1,$hoChartData{Phase}->[3]],
	#	values => [$hoChartData{$keyw}->[0], $hoChartData{$keyw}->[1], $hoChartData{$keyw}->[1], $hoChartData{$keyw}->[2]+1,$hoChartData{$keyw}->[3]],
	#);

	# Add chart title, some axis labels (done via primary chart)
	($cT eq "") && ($cT = $keyw);
	$spC->set_title(name => $cT);
	#$spC->set_x_axis( name => $keyw);
	#$spC->set_y_axis( name => $keyw, name_font=>{rotation=>-90});
	$spC->set_size(x_scale => 1.4);
	$spC->set_legend( position => 'bottom');

	# Insert chart, finishing the work
	$sheet->insert_chart(xl_rowcol_to_cell($oR,$oC, 0, 0),$spC);

	return 0;
}

sub conv_to_hours($){
	### convert string format HH:MM:SS to number in hours
	#	notice: the output result may contain DD (days), but now this sub written for up-to Hours only
	my $iStr = shift;
	#-> validating input
	if($iStr=~/^[\d:]+$/){
		#good to go
	}else{
		$DEBUG && print "dbg:: conv_to_hours: out-of-scope input='$iStr', ignored.\n";
		return $iStr;
	}
	my @tmpa = split ':', $iStr;
	my $sec  = pop @tmpa;
	my $min  = 0; (@tmpa) && ($min = pop @tmpa);
	my $hour = 0; (@tmpa) && ($hour = pop @tmpa);
	if (@tmpa){
		$DEBUG && print "dbg:: conv_to_hours: weird, over hour detected='@tmpa', ignored.\n";
		return $iStr;
	}else{
	}

	#
	return sprintf("%.2f", $hour+$min/60+$sec/3600);
}

#==========================================#

#==========================================#


#--- Check inpput option
if (@ARGV < 2) {
  &sub_print_usage();
  exit;
}

#-- init data
while (my $arg = shift @ARGV) {
  if ($arg =~ /^-/) { &sub_check_syntax($arg);}
  if ($arg =~ /-spec/) {
    my $specfile = shift @ARGV;
    &sub_read_spec($specfile,\%SPEC);
  }

  if ($arg =~ /-workdir/) {
    my $tmp = shift @ARGV;
    chomp $tmp;
    if ($tmp ne "" && defined $tmp) {$SPEC{DIR}{Working} = $tmp;}
  }
  if ($arg =~ /-rptdir/) {
    my $tmp = shift @ARGV;
    chomp $tmp;
    $SPEC{DIR}{RPT} = $tmp;
  }
  if ($arg =~ /-logdir/) {
    my $tmp = shift @ARGV;
    chomp $tmp;
    $SPEC{DIR}{LOG} = $tmp;
  }
  if ($arg =~ /-only/) {
    my $tmp = shift @ARGV;
    chomp $tmp;
    $onlyphase = uc($tmp);
  }
}


&sub_update_direct_link(\%SPEC);
&sub_update_latest_log_file(\%SPEC);
&sub_update_excel_table($EXCEL_ROW_HEADER,$EXCEL_COL_HEADER);

#--- MAIN 

my %QOR;

if (!defined $onlyphase) {
  my %init  = &sub_phase_reading(\%SPEC,"INIT");
  my %pod  = &sub_phase_reading(\%SPEC,"POD");
  my %cod  = &sub_phase_reading(\%SPEC,"COD");
  my %route  = &sub_phase_reading(\%SPEC,"ROUTE");
  my %prod  = &sub_phase_reading(\%SPEC,"PROD");
  $QOR{INIT} = &sub_simplify_output(%init);
  $QOR{POD} = &sub_simplify_output(%pod);
  $QOR{COD} = &sub_simplify_output(%cod);
  $QOR{ROUTE} = &sub_simplify_output(%route);
  $QOR{PROD} = &sub_simplify_output(%prod);
  &sub_update_std_oh_ratio(\%QOR);
} else {
  my %only = &sub_phase_reading(\%SPEC,$onlyphase);
  $QOR{$onlyphase} = &sub_simplify_output(%only);
}


if ($DEBUG) {
 print Dumper(\%SPEC);
 print Dumper(\%EXCEL_SPEC);
 print Dumper(\%EXCEL_TBL);
 print Dumper(\%QOR);
}

&sub_make_excel_qor(%QOR);
#==========================================#
#History
#v6.1 ManD	Add some subs to draw charts
#			change the duration output to be in hours (format='%.1f')
### modeline, workable for developers working on vim editor only
#{{{
# vi: fen fdm=marker fmr={{{,}}} fcl=all ai nowrap ts=4 softtabstop=4 shiftwidth=4
#}}}
#-eof
