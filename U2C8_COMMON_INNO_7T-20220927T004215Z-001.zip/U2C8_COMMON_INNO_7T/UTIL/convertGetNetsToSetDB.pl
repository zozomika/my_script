#!/usr/bin/perl

while (<>) {
	s|set_dont_touch\s*\[get_nets\s|catch { set_db hnet:|gi;
	s|\]\s*true| .dont_touch true }|gi;
	print ;
}
