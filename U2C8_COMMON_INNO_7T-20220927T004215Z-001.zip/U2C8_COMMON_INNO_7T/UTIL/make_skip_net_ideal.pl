#!/usr/bin/perl -w

open (INPUT_FILE,"<$ARGV[0]") or die ("ARGV[0] does not exist.\n");

foreach $III (<INPUT_FILE>) {
   chomp $III;
   printf("set_ideal_network -no_propagate [get_object_name [get_nets $III]]\n");
}
close(INPUT_FILE);
