#!/usr/bin/perl
#
#2016-08-08: for Tensilica run11p
#
($report)=@ARGV;
#($min,$max,$range)=@ARGV;
die "cannot open $report" if(! -f $report); 

$min=0;
$max=4;
$range=0.1;

undef %histo;
$period=$max;
while($min<$period){
  $histo{$period}=0;
  $period-=$range;
  $period=sprintf("%.3f",$period);
}

open(IN,$report);

$line=0;
$lt_min=1000;
$lt_max=-1000;
$lt_tot=0;
while(<IN>){
  if(/[-0-9.]+\s+[-0-9.]+\s+([-0-9.]+)\s+\w+\s+(\S+)/){
    $line++;
    $v=$1;
    $pin=$2;
    $info{$pin}=$v;
    $lt_min=$v if($lt_min > $v);
    $lt_max=$v if($lt_max < $v);
    $lt_tot+=$v;
    #print "$v\n";
    if($v>$max){
      $histo{$max}++;
      next;
    }
    $period=$max;
    while($v<$period){
      $period-=$range;
      $period=sprintf("%.3f",$period);
    }
    #print "$v: $period\n";
    $histo{$period}++;
  }
}

$total=0;
foreach $k (sort {$a<=>$b} keys %histo){
  printf "#%6s : %8d\n", $k, $histo{$k};
  $total+=$histo{$k};
}
$lt_avg=$lt_tot/$line;
printf "#%6s : %8d\n", total, $total;
printf "#%6s : %8d\n", lines, $line;
print  "#\n";
printf "#%6s : %8.3f\n", min, $lt_min;
printf "#%6s : %8.3f\n", max, $lt_max;
printf "#%6s : %8.3f\n", avg, $lt_avg;

$c=0;
$bin=0.02;
foreach $k (sort {$info{$a} <=> $info{$b}} keys %info){
  #printf "a %f\n", ($info{$k}-$lt_avg);
  #printf "b %f\n", ($info{$k}-$lt_avg)/$bin;
  $n=int(($info{$k}-$lt_avg)/$bin);
  if($n != 0){
    $c++;
    printf "set_clock_latency %.3f [get_pins {$k}]\n", $info{$k}-$lt_avg;
    #printf "set_clock_latency %.3f [get_pins {$k}]\n", $info{$k};
  }
  #printf "%5s : $n : $k\n",$info{$k};
}
print "#num=$c\n";

#open(IN,$report);
#
#while(<IN>){
#  if(/[-0-9.]+\s+[-0-9.]+\s+([-0-9.]+)/){
#    $line++;
#    $v=$1;
#    $lt_min=$v if($lt_min > $v);
#    $lt_max=$v if($lt_max < $v);
#    $lt_tot+=$v;
#    #print "$v\n";
#    if($v>$max){
#      $histo{$max}++;
#      next;
#    }
#    $period=$max;
#    while($v<$period){
#      $period-=$range;
#      $period=sprintf("%.3f",$period);
#    }
#    #print "$v: $period\n";
#    $histo{$period}++;
#  }
#}
