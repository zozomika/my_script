#!/usr/bin/perl -w
open ( INFILE , "<$ARGV[0]" ) ;
$c0    = 0;
$c400  = 0;
$c800  = 0;
$c1200 = 0;
$c1600 = 0;
$c2000 = 0;
$c2400 = 0;
$c2800 = 0;
$c3200 = 0;

foreach $ONELINE (<INFILE>){
  chomp $ONELINE ;
  $ONELINE         =~ s/^\s*//;
  @oneline         = split /\s+/, $ONELINE;

  if ($oneline[0] ne "version" && $oneline[0] ne "mtarpt=" && $oneline[0] ne "output" && $oneline[0] ne "output" && $oneline[0] ne "key" && $oneline[0] ne "nprint" && $oneline[0] ne "npath" && $oneline[0] ne "distance"){
    if ($oneline[0] >= 0    && $oneline[0] < 400 ){$c0    = $c0   + 1;}
    if ($oneline[0] >= 400  && $oneline[0] < 800 ){$c400  = $c400 + 1;}
    if ($oneline[0] >= 800  && $oneline[0] < 1200){$c800  = $c800 + 1;}
    if ($oneline[0] >= 1200 && $oneline[0] < 1600){$c1200 = $c1200 + 1;}
    if ($oneline[0] >= 1600 && $oneline[0] < 2000){$c1600 = $c1600 + 1;}
    if ($oneline[0] >= 2000 && $oneline[0] < 2400){$c2000 = $c2000 + 1;}
    if ($oneline[0] >= 2400 && $oneline[0] < 2800){$c2400 = $c2400 + 1;}
    if ($oneline[0] >= 2800 && $oneline[0] < 3200){$c2800 = $c2800 + 1;}
    if ($oneline[0] >= 3200                      ){$c3200 = $c3200 + 1;}
  }
}
print "0    - 400  : $c0    \n" ;
print "400  - 800  : $c400  \n" ;
print "800  - 1200 : $c800  \n" ;
print "1200 - 1600 : $c1200 \n" ;
print "1600 - 2000 : $c1600 \n" ;
print "2000 - 2400 : $c2000 \n" ;
print "2400 - 2800 : $c2400 \n" ;
print "2800 - 3200 : $c2800 \n" ;
print "3200 <      : $c3200 \n" ;
close ( INFILE ) ;
