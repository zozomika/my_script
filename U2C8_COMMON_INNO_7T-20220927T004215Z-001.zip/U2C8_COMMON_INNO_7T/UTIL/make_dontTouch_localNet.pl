#!/usr/bin/perl -w

open (INPUT_FILE,"<$ARGV[0]") or die ("ARGV[0] does not exist.\n");

foreach $III (<INPUT_FILE>) {
   chomp $III;
   printf("set_db hnet:$III .dont_touch true\n");
}
close(INPUT_FILE);
