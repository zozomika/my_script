#!/usr/bin/perl
#######################################
## AUTHOR  :  PhuocLe-Backend1       ##
## DATE    :  13/02/2018             ##
## PURPOSE :  FORMAT REPORT INNO     ##
#######################################

#0 read input file 
$input_file = $ARGV[0];

if ($input_file eq '') {
  usage();
  exit;
} elsif ($input_file =~ /.gz$/) {
  open(data, "gunzip -c $input_file |");
} else { 
  open(data,"<$input_file"); 
}

#1 initial define
$st  = 0;
$cnt = 0;
$check = 1;
$acr_l = "-----------------------------------------------------------------------------------------------------------------------------------------";
$acr_a = "-------------------------------------------------------------------------------------------------------------";

#2 MAIN
while(<data>) {
 $line     = ($_) ;
 @line_arr = split(" ",$line); 

 if ($st == 1) {
  if ($line !~ $acr_l) {
    if (($cnt == 2) or ($cnt == 5)) {
     if ($check == 1) {
       print "     $acr_l$acr_a\n";
       printf("%-5s %-160s %-10s %-13s %-10s %-10s %-10s %-15s %-3s %-5s\n","","Pin (Cell)","Fan","Load","Slew","Icr","Delay","Arival","edg","derate");
       print "     $acr_l$acr_a\n";
       $check = 0;
     }
     print_line(@line_arr);
    } elsif ($cnt == 3) {
     print "$line";
    }
  }
 } else {
  print "$line";
 }

 if ($line =~ /Timing Path/) {
  $st   = 1;
 } elsif ($line =~ $acr_l) {
  $cnt += 1;
  $check = 1;
  if ($cnt ==3) {
   print "     $acr_l$acr_a\n";
  }
 }

 if ($cnt == 6) {
  print "     $acr_l$acr_a\n";
  print "\n";
  $st  =  0;
  $cnt =  0;
 }
}


#3 SUB
sub usage {
 print "*-------------------------------------------------------------------------------------------*\n";
 print "| phuocle-backend1 *                                                                        |\n";
 print "*-------------------------------------------------------------------------------------------*\n";
 print "* USAGE:     format.pl  <timing.rep>                                                        |\n";
 print "*-------------------------------------------------------------------------------------------*\n";
}

sub print_line {
 my @input_line = (@_);
 my $pin    = $input_line[0];
 my $ref    = $input_line[1];
 my $net    = $input_line[2];
 my $fan    = $input_line[3];
 my $cap    = $input_line[4];
 my $tran   = $input_line[5];
 my $inc    = $input_line[6];
 my $del    = $input_line[7];
 my $arv    = $input_line[8];
 my $edg    = $input_line[9];
 my $derate = $input_line[10]; 
 
 if ($ref ne "-") {  
   if ($fan ne "-") {
     printf("%5s %-160s %-10s %-10s \n","","$net (net)",$fan,$cap);
   }
   printf("%5s %-185s %-10s %-10s %-10s %-15s %-3s %-10s\n","","$pin  ($ref)",$tran,$inc,$del,$arv,$edg,$derate);
 } else {
   printf("%5s %-185s %-10s %-10s %-10s %-15s %-3s %-10s\n","","$pin ",$tran,$inc,$del,$arv,$edg,$derate);
 }

}
#4 FINISH
close(data);

## < FINISH > ##




